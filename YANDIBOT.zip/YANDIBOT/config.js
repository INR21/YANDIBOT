global.owner = ['6282216414605'] // Put your number here
global.mods = ['6282216414605','628989031500'] // Want some help?
global.prems = ['6285803107612','628989031500','6282216414605'] // Premium user has unlimited limit
global.APIs = { // API Prefix
  // name: 'https://website'
  nrtm: 'https://nurutomo.herokuapp.com',
  xteam: 'https://api.xteam.xyz'
}
global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.xteam.xyz': 'MIMINETBOT'
}
global.packname = 'Sticker'
global.author = 'Lord Mimin'



let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
