let handler = async m => m.reply(`
╭──°❀❬ *DONASI* ❭❀°──
│• *Telkomsel:* [0822 1641 4605]
│• *3:* [0822 1641 4605]
│• *Gopay:* [082216414605]
│ 「 *Chat OWNER* 」
│ > *Ingin donasi? Wa.me/6282216414605*
╰────────────────

Isi buat yg mau donasi
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
