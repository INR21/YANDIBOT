let handler  = async (m, { conn, usedPrefix: _p }) => {
let info = `
╭──°❀❬ *INFO* ❭❀°──
│
│> Bot Recoded By :
│• PGID
│> Owner By : 
│• YANDIBOT
│
│> Bot Dibuat Dengan :
│• JavaScript via NodeJS
│• FFmpeg
│
│> Thanks To :
│• Nurutomo
│• Drawl Nag
│• RC047/Kuhong
│• Ibnu/Mimin
│• YANDIBOT
│
╰────────────────

╭──°❀❬ *DONASI* ❭❀°──
│• *Telkomsel:* [0822 1641 4605]
│• *3:* [0822 1641 4605]
│• *Gopay:* [082216414605]
│ 「 *Chat OWNER* 」
│ > *Ingin donasi? Wa.me/6282216414605*
╰────────────────
`.trim()

conn.fakeReply(m.chat, info, '0@s.whatsapp.net', '*BOT TERVERIFIKASI*', 'status@broadcast')
}
handler.help = ['info']
handler.tags = ['info']
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
