let fetch = require('node-fetch')
let handler = async (m, { conn, args }) => {
   response = args.join(' ').split('|')
  m.reply('Sedang Diproses...')
  let res = await fetch(`https://leyscoders-api.herokuapp.com/api/darkjoke?apikey=YANDIBOT`)
  let json = await res.json()
  conn.sendFile(m.chat, json.result, 'darkjoke.jpg', `Woy siapa yg matiin lampu woy:v`, m, false)
}
handler.help = ['darkjoke'].map(v => v + ' ')
handler.tags = ['image']
handler.command = /^(darkjoke)$/i

module.exports = handler

