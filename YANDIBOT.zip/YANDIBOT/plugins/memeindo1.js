let fetch = require('node-fetch')
let handler = async (m, { conn, args }) => {
   response = args.join(' ').split('|')
  m.reply('Sedang Diproses...')
  let res = await fetch(`https://leyscoders-api.herokuapp.com/api/memeindo?apikey=YANDIBOT`)
  let json = await res.json()
  conn.sendFile(m.chat, json.result, 'memeindo.jpg', `Nih Meme`, m, false)
}
handler.help = ['meme'].map(v => v + ' ')
handler.tags = ['image']
handler.command = /^(meme)$/i

module.exports = handler

