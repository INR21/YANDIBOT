let fetch = require('node-fetch')
let handler = async (m, { conn, args }) => {
   response = args.join(' ')
  if (!args[0]) throw 'Masukkan Parameter'
  m.reply('Sedang Diproses...')
  let res = await fetch(`https://api.zeks.xyz/api/lithgtext?text=${response}&apikey=apivinz`)
  let json = await res.json()
  conn.sendFile(m.chat, json.result, '1.jpg', `Nih kak`, m, false)
}
handler.help = ['cekk'].map(v => v + ' <teks>')
handler.tags = ['sticker']

handler.command = /^(cekk)$/i

module.exports = handler
